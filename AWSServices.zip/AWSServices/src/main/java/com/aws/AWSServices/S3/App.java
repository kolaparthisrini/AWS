package com.aws.AWSServices.S3;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;
 
/**
 * @author skolapar
 *
 */
public class App
{
  public static void main(String[] args) throws Exception
  {
    AWSCredentials credentials = new BasicAWSCredentials("AKIAI4ALHS3DBIVVYRHQ", "jOZspvxdKLQVq3FyLj0ZGbs/JZr3SrQhMRo/s0H+");
    AmazonEC2 ec2 = new AmazonEC2Client(credentials);
 
    DescribeInstancesResult insResult = ec2.describeInstances();
 
    int count = 1;
    for (Reservation reservation : insResult.getReservations())
    {
      for(Instance instance : reservation.getInstances())
      {
        System.out.println("Instance # " + count++
                + "\n InstanceId: " + instance.getInstanceId()
                + "\n InstanceType: " + instance.getInstanceType()
                + "\n Public IP: " + instance.getPublicIpAddress());
      }
    }
  }
}